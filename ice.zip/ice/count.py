import hashlib
import ecdsa
import time
import secp256k1 as ice
from multiprocessing import Pool
import random

def pubkey_to_h160(addr_type, iscompressed, pubkey_bytes):
    return ice.pubkey_to_h160(addr_type, iscompressed, pubkey_bytes)

def split_into_random_chunks(start, end, num):
    all_keys = list(range(start, end + 1))
    random.shuffle(all_keys)
    step = len(all_keys) // num
    return [all_keys[i:i + step] for i in range(0, len(all_keys), step)]

def find_private_key(keys):
    target_h160, private_keys = keys
    curve = ecdsa.SECP256k1

    for i in private_keys:
        print(f"Checking private key: {i}", flush=True)
        private_key = ecdsa.SigningKey.from_secret_exponent(i, curve)
        public_key = private_key.get_verifying_key().to_string("compressed")
        current_h160 = pubkey_to_h160(0, True, public_key)

        if current_h160 == target_h160:
            return i

    return None

if __name__ == "__main__":
    target_h160 = bytes.fromhex("5a416cc9148f4a377b672c8ae5d3287adaafadec")
    start_number = 136870911
    end_number = 536870911
    num_processes = 2
   
    random_chunks = split_into_random_chunks(start_number, end_number, num_processes)
    chunks_with_target = [(target_h160, chunk) for chunk in random_chunks]
    
    start_time = time.time()
    
    with Pool(num_processes) as pool:
        for private_key in pool.imap(find_private_key, chunks_with_target):
            if private_key:
                # Terminate the pool to stop other processes
                pool.terminate()
                # Write to file
                with open('file.txt', 'w') as f:
                    f.write(f"Private key found: {private_key}\n")
                    f.write(f"Private key found (hex): {hex(private_key)[2:]}\n")
                break
                
    end_time = time.time()

    if private_key:
        print(f"Private key found: {private_key}")
        print(f"Time taken: {end_time - start_time} seconds")
    else:
        print("No private key found in the specified range.")
